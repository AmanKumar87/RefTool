=========================================
 Scholar Research Assistant v1.0 - README
=========================================

Thank you for using the Scholar Research Assistant! This tool helps you automatically find and format references from Google Scholar for your research papers.

--------------------
1. Prerequisites
--------------------

Before running the setup, please make sure you have the following installed on your Windows computer:

- Python: The application requires Python to be installed. You can get it from python.org. During installation, make sure to check the box that says "Add Python to PATH".
- An Internet Connection: Required for the first-time setup to download necessary packages.

--------------------
2. First-Time Setup
--------------------

The first time you run the application, it will automatically set itself up.

1. Double-click the `ScholarScraper_Setup.exe` file.
2. A black terminal window will appear. It will automatically:
   - Create a local, safe "virtual environment".
   - Install all the required Python libraries (like Streamlit and Selenium). This may take a few minutes. Please be patient.
3. Once the installation is complete, the script will automatically launch the application in your default web browser.

For all future uses, the setup will be skipped, and the application will launch immediately.

--------------------
3. How to Use the Application
--------------------

The application works in a simple, step-by-step process:

Step 1: Set Your Scraping Strategy
   - Use the sidebar on the left to define your search.
   - Enter Research Topic: Type the subject you are researching.
   - Select Years to Scrape: Choose one or more years (2020+) to find papers from.
   - Pages to Scrape per Year: Set how many pages of results you want to process for each year.
   - Choose Final Citation Format: Select the format you need for your final list (e.g., Chicago, APA).

Step 2: Launch the Browser
   - Click the green "1. Launch Browser & Prepare" button.
   - A new Chrome browser window will open and perform the first search.

Step 3: Solve CAPTCHA (If Necessary)
   - Look at the new Chrome window. If Google asks you to prove you are not a robot (a CAPTCHA), please solve it.
   - Once you see the normal list of search results, you can proceed.

Step 4: Scrape All Pages
   - Return to the application in your original browser tab.
   - Click the "2. Scrape All Pages" button.
   - The application will now take over and automatically scrape all the pages and years you specified. A spinner will show the progress.

Step 5: Build Your Reference List
   - Once scraping is complete, the "Reference Pool" will be created.
   - Use the "Build Your Reference List" section to randomly select papers from the pool. You can either take a random number from the entire pool ("Any") or specify how many you want from each year ("Choose").
   - Click "Generate My Reference List".

Step 6: Final Review and Download
   - Your final, shuffled list will appear for review. Uncheck any papers you don't want.
   - Click "Get Formatted Citations & Prepare Download".
   - The final, formatted citations will appear, along with "Download as Word (.docx)" and "Download as CSV" buttons.

To Finish: You can close the browser window that was opened by Selenium and click the "Quit Browser Session" button in the app's sidebar to clean up.

--------------------
4. Troubleshooting
--------------------

- "Failed to launch browser" error: Make sure you have Google Chrome installed on your computer.
- Scraping seems stuck: Check the Chrome window that the app opened. There might be a new CAPTCHA that needs to be solved.

Thank you again for using the tool!
