# import streamlit as st
# import time
# import datetime
# import pandas as pd
# import re
# import random
# from docx import Document
# from io import BytesIO

# from selenium import webdriver
# from selenium.webdriver.chrome.service import Service as ChromeService
# from webdriver_manager.chrome import ChromeDriverManager
# from selenium.webdriver.common.by import By
# from selenium.webdriver.common.keys import Keys
# from selenium.webdriver.support.ui import WebDriverWait
# from selenium.webdriver.support import expected_conditions as EC
# from selenium.common.exceptions import NoSuchElementException, TimeoutException

# # --- Page Configuration and CSS ---
# st.set_page_config(page_title="Advanced Scholar Scraper", page_icon="🔬", layout="wide")

# def load_css(file_name):
#     try:
#         with open(file_name) as f:
#             st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
#     except FileNotFoundError:
#         st.warning(f"'{file_name}' not found. UI will be unstyled.")
# load_css("style.css")

# # --- Helper Functions ---
# def create_word_document(citations_list):
#     document = Document()
#     document.add_heading('References', level=1)
#     for citation in citations_list:
#         document.add_paragraph(citation, style='List Number')
#     bio = BytesIO()
#     document.save(bio)
#     return bio.getvalue()

# def create_csv_file(citations_list):
#     df = pd.DataFrame(citations_list, columns=["Reference"])
#     return df.to_csv(index=False).encode('utf-8')

# # --- Selenium Functions ---
# # def resume_scraping(driver, years_to_scrape, pages_per_year, topic):
# #     scraped_papers_data = []
# #     wait = WebDriverWait(driver, 10)
# #     for i, year in enumerate(years_to_scrape):
# #         if i > 0:
# #             st.toast(f"Searching for year: {year}...")
# #             url = f"https://scholar.google.com/scholar?q={topic.replace(' ', '+')}&as_ylo={year}&as_yhi={year}"
# #             driver.get(url)
# #         else:
# #              st.toast(f"Starting with year: {year}...")
# #         for page_num in range(pages_per_year):
# #             st.toast(f"Scanning page {page_num + 1} for year {year}...")
# #             try:
# #                 wait.until(EC.presence_of_element_located((By.ID, "gs_res_ccl_mid")))
# #                 papers_on_page = driver.find_elements(By.CSS_SELECTOR, "div.gs_r.gs_or.gs_scl")
# #                 for paper in papers_on_page:
# #                     try:
# #                         title = paper.find_element(By.CSS_SELECTOR, "h3.gs_rt a").text
# #                         author_year_line = paper.find_element(By.CSS_SELECTOR, "div.gs_a").text
# #                         year_match = re.search(r'\b(19[89]\d|20\d{2})\b', author_year_line)
# #                         publication_year = int(year_match.group(0)) if year_match else 0
# #                         authors = author_year_line.split(' - ')[0]
                        
# #                         # --- NEW: Get the stable data-cid attribute ---
# #                         cid = paper.get_attribute('data-cid')

# #                         scraped_papers_data.append({
# #                             "cid": cid, # Store the unique ID
# #                             "title": title, 
# #                             "authors": authors, 
# #                             "year": publication_year
# #                         })
# #                     except NoSuchElementException:
# #                         continue
# #             except TimeoutException:
# #                 st.warning(f"No results found for {year} on page {page_num + 1}.")
# #                 break
# #             try:
# #                 next_button = wait.until(EC.element_to_be_clickable((By.LINK_TEXT, "Next")))
# #                 driver.execute_script("arguments[0].scrollIntoView(true);", next_button)
# #                 time.sleep(1)
# #                 next_button.click()
# #             except (NoSuchElementException, TimeoutException):
# #                 st.toast(f"No more pages for year {year}.")
# #                 break
# #     st.toast("Scraping complete!")
# #     return scraped_papers_data

# # --- Replace your existing resume_scraping function with this one ---

# def resume_scraping(driver, years_to_scrape, pages_per_year, topic):
    
#     # This is the new helper function that will live inside our main scraper
#     def parse_citation_data(citations_dict):
#         title, year = "Title not found", 0
#         if "Chicago" in citations_dict:
#             match = re.search(r'"(.*?)"', citations_dict["Chicago"])
#             if match: title = match.group(1)
#         elif "MLA" in citations_dict:
#             match = re.search(r'“(.*?)”', citations_dict["MLA"])
#             if match: title = match.group(1)
        
#         for fmt_text in citations_dict.values():
#             year_match = re.search(r'\b(20\d{2})\b', fmt_text)
#             if year_match:
#                 year = int(year_match.group(0))
#                 break
#         return title, year

#     # This is the main logic
#     reference_pool = []
#     wait = WebDriverWait(driver, 10)
    
#     for i, year_to_search in enumerate(years_to_scrape):
#         if i > 0:
#             st.toast(f"Searching for year: {year_to_search}...")
#             url = f"https://scholar.google.com/scholar?q={topic.replace(' ', '+')}&as_ylo={year_to_search}&as_yhi={year_to_search}"
#             driver.get(url)
#         else:
#              st.toast(f"Starting with year: {year_to_search}...")

#         for page_num in range(pages_per_year):
#             st.toast(f"Processing page {page_num + 1} for year {year_to_search}...")
#             try:
#                 wait.until(EC.presence_of_element_located((By.ID, "gs_res_ccl_mid")))
#                 papers_on_page = driver.find_elements(By.CSS_SELECTOR, "div.gs_r.gs_or.gs_scl")
                
#                 if not papers_on_page: break

#                 cids = [paper.get_attribute('data-cid') for paper in papers_on_page if paper.get_attribute('data-cid')]
                
#                 for cid in cids:
#                     try:
#                         paper_container = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, f"div[data-cid='{cid}']")))
#                         cite_button = paper_container.find_element(By.CSS_SELECTOR, "a.gs_or_cit.gs_or_btn")
#                         driver.execute_script("arguments[0].click();", cite_button)
                        
#                         pop_up = wait.until(EC.visibility_of_element_located((By.ID, "gs_cit")))
#                         rows = pop_up.find_elements(By.TAG_NAME, "tr")
                        
#                         citations_dict = {row.find_element(By.TAG_NAME, "th").text: row.find_element(By.TAG_NAME, "td").text for row in rows}
                        
#                         title, parsed_year = parse_citation_data(citations_dict)

#                         if title != "Title not found":
#                             reference_pool.append({
#                                 "title": title, 
#                                 "year": parsed_year, 
#                                 "citations": citations_dict # Store all formats
#                             })
                        
#                         close_button = pop_up.find_element(By.ID, "gs_cit-x")
#                         driver.execute_script("arguments[0].click();", close_button)
#                         wait.until(EC.invisibility_of_element_located((By.ID, "gs_cit")))
#                     except Exception:
#                         continue
#             except TimeoutException:
#                 break
            
#             try: # Pagination
#                 next_button = driver.find_element(By.LINK_TEXT, "Next")
#                 driver.execute_script("arguments[0].scrollIntoView(true);", next_button)
#                 time.sleep(0.5)
#                 next_button.click()
#             except NoSuchElementException:
#                 break
    
#     st.toast("Scraping complete!")
#     return reference_pool
# # --- UPDATED FINAL CITATION FUNCTION ---
# # def get_final_citations(driver, papers_to_cite, citation_format):
# #     citations = []
# #     if not driver:
# #         st.error("Browser session not found. Please start a new scrape.")
# #         return [], ["Browser session was not found."]
    
# #     wait = WebDriverWait(driver, 5)
# #     errors = []
    
# #     for paper_data in papers_to_cite:
# #         cid_to_find = paper_data['cid']
# #         title_to_find = paper_data['title']
# #         st.toast(f"Getting citation for '{title_to_find[:30]}...'")
        
# #         try:
# #             # --- NEW ROBUST METHOD: Find the paper using its unique data-cid ---
# #             paper_container = driver.find_element(By.CSS_SELECTOR, f"div[data-cid='{cid_to_find}']")
            
# #             # Now find the cite button within this fresh container
# #             cite_button = paper_container.find_element(By.CSS_SELECTOR, "a.gs_or_cit.gs_or_btn")
# #             cite_button.click()
            
# #             pop_up = wait.until(EC.visibility_of_element_located((By.ID, "gs_cit")))
# #             rows = pop_up.find_elements(By.TAG_NAME, "tr")
# #             for row in rows:
# #                 if row.find_element(By.TAG_NAME, "th").text == citation_format:
# #                     citations.append(row.find_element(By.TAG_NAME, "td").text)
# #                     break
# #             pop_up.find_element(By.ID, "gs_cit-x").click()
# #             time.sleep(0.5)
# #         except Exception as e:
# #             error_message = f"Could not get citation for '{title_to_find}'. Reason: {e}"
# #             errors.append(error_message)
            
# #     return citations, errors
# # --- Replace your get_final_citations function with this one ---


# # --- Initialize Session State ---
# if 'app_state' not in st.session_state: st.session_state.app_state = 'initial'
# if 'driver' not in st.session_state: st.session_state.driver = None
# if 'reference_pool' not in st.session_state: st.session_state.reference_pool = []
# if 'final_selection' not in st.session_state: st.session_state.final_selection = []
# if 'final_citations' not in st.session_state: st.session_state.final_citations = []
# if 'citation_errors' not in st.session_state: st.session_state.citation_errors = []
# if 'select_all_papers' not in st.session_state: st.session_state.select_all_papers = False

# # --- UI Sidebar ---
# with st.sidebar:
#     st.header("Scraping Strategy")
#     search_topic = st.text_input("Enter Research Topic", placeholder="e.g., Quantum computing")
#     current_year = datetime.date.today().year
#     year_options = list(range(2020, current_year + 1)); year_options.sort(reverse=True)
#     selected_years = st.multiselect("Select Years to Scrape (2020+)", options=year_options, default=year_options[0:1])
#     pages_to_scrape = st.number_input("Pages to Scrape per Year", min_value=1, max_value=10, value=1, step=1)
#     st.session_state.citation_format = st.selectbox("Choose Citation Format", ["Chicago", "MLA", "APA", "Harvard", "Vancouver"])

#     if st.button("1. Launch Browser & Prepare", use_container_width=True, type="primary"):
#         if search_topic and selected_years:
#             st.session_state.scrape_settings = {"topic": search_topic, "years": selected_years, "pages": pages_to_scrape}
#             st.session_state.app_state = 'initial' # Reset states
#             st.session_state.reference_pool = []; st.session_state.final_selection = []; st.session_state.final_citations = []; st.session_state.citation_errors = []
#             try:
#                 if 'driver' in st.session_state and st.session_state.driver: st.session_state.driver.quit()
#                 options = webdriver.ChromeOptions()
#                 st.session_state.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=options)
#                 first_year = selected_years[0]
#                 url = f"https://scholar.google.com/scholar?q={search_topic.replace(' ', '+')}&as_ylo={first_year}&as_yhi={first_year}"
#                 st.session_state.driver.get(url)
#                 st.session_state.app_state = 'browser_open'; st.rerun()
#             except Exception as e:
#                 st.error(f"Failed to launch browser: {e}")
#         else:
#             st.warning("Please enter a topic and select at least one year.")
    
#     st.markdown("---")
#     if st.button("Quit Browser Session", use_container_width=True, type="secondary"):
#         if 'driver' in st.session_state and st.session_state.driver:
#             st.session_state.driver.quit()
#             st.session_state.driver = None
#             st.session_state.app_state = 'initial'; st.session_state.reference_pool = []; st.session_state.final_selection = []; st.session_state.final_citations = []
#             st.success("Browser session closed."); time.sleep(1); st.rerun()

# # --- Main Page Area ---
# st.title("🔬 Advanced Research Assistant")

# if st.session_state.app_state in ['initial', 'browser_open', 'scraping']:
#     if st.session_state.app_state == 'initial':
#         st.info("⬅️ Set your scraping strategy and click 'Launch & Prepare' to begin.")
#     elif st.session_state.app_state == 'browser_open':
#         st.subheader("Action Required")
#         st.success("Browser is open. Please solve any CAPTCHA if it appears.")
#         st.info("Once you see the normal search results list, click the button below to begin scraping.")
#         if st.button("2. Scrape All Pages", use_container_width=True):
#             st.session_state.app_state = 'scraping'; st.rerun()
#     elif st.session_state.app_state == 'scraping':
#         with st.spinner("Scraping all specified pages... Please wait."):
#             settings = st.session_state.scrape_settings
#             results = resume_scraping(st.session_state.driver, settings['years'], settings['pages'], settings['topic'])
#             st.session_state.reference_pool = results
#             st.session_state.app_state = 'done'; st.rerun()

# elif st.session_state.app_state == 'done':
#     # Display any captured errors from the last citation scrape at the top
#     if st.session_state.citation_errors:
#         st.subheader("⚠️ Errors Encountered During Citation Scraping")
#         for error in st.session_state.citation_errors:
#             st.warning(error)
#         st.markdown("---")
    
#     # Display download links if we have successful citations
#     if st.session_state.final_citations:
#         st.subheader("✅ Success! Your References Are Ready")
#         st.text_area("Formatted citations:", "\n\n".join(st.session_state.final_citations), height=300)
#         col1, col2 = st.columns(2)
#         with col1:
#             st.download_button(label="Download as Word (.docx)", data=create_word_document(st.session_state.final_citations), file_name="references.docx", mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document", use_container_width=True)
#         with col2:
#             st.download_button(label="Download as CSV", data=create_csv_file(st.session_state.final_citations), file_name="references.csv", mime="text/csv", use_container_width=True)

#     # Display final review list if it exists and we don't have citations yet
#     elif st.session_state.final_selection:
#         st.markdown("---")
#         st.subheader("Your Generated Reference List (Final Review)")
#         st.info("Review the list below. Uncheck any papers you wish to exclude.")
#         with st.form("citation_form"):
#             selections = {i: st.checkbox(f"**{p['title']}** ({p['year']})", value=True, key=f"final_{i}") for i, p in enumerate(st.session_state.final_selection)}
#             submitted_for_citation = st.form_submit_button("Get Formatted Citations & Prepare Download")
#             if submitted_for_citation:
#                 papers_to_cite = [st.session_state.final_selection[i] for i, checked in selections.items() if checked]
#                 with st.spinner("Clicking 'Cite' buttons and getting formatted references..."):
#                     final_citations, errors = get_final_citations(st.session_state.driver, papers_to_cite, st.session_state.citation_format)
#                     st.session_state.final_citations = final_citations
#                     st.session_state.citation_errors = errors
#                 st.rerun()

#     # Display the mixer UI if the pool exists and no final list has been generated yet
#     elif st.session_state.reference_pool:
#         st.subheader("Reference Pool Created")
#         pool = st.session_state.reference_pool
#         df = pd.DataFrame([p for p in pool if isinstance(p.get('year'), int) and p.get('year') > 0])
#         st.success(f"Created a pool with **{len(df)}** valid papers.")
#         if not df.empty:
#             st.write("#### Pool Summary (Papers per Year)"); st.table(df['year'].value_counts().sort_index(ascending=False))
#         st.markdown("---")
#         st.subheader("Build Your Reference List")
#         mixing_strategy = st.radio("How do you want to select references?", ["Randomly from entire pool (Any)", "Specify count per year (Choose)"], key="mixing_strategy")
        
#         with st.form("mixer_form"):
#             total_random_count, counts_per_year = 0, {}
#             if mixing_strategy == "Randomly from entire pool (Any)":
#                 if not df.empty: total_random_count = st.number_input("Total references to generate:", min_value=1, max_value=len(df), value=min(10, len(df)), step=1)
#             else:
#                 if not df.empty:
#                     st.write("**Enter the number of references to select from each year:**")
#                     for year in sorted(df['year'].unique(), reverse=True):
#                         max_for_year = len(df[df['year'] == year])
#                         counts_per_year[year] = st.number_input(f"Count for {year} (max: {max_for_year})", min_value=0, max_value=max_for_year, value=0, step=1, key=f"year_{year}")
            
#             submitted = st.form_submit_button("Generate My Reference List")
#             if submitted:
#                 final_selection_data = []
#                 if mixing_strategy == "Randomly from entire pool (Any)":
#                     if total_random_count > 0 and not df.empty: final_selection_data = df.sample(n=total_random_count).to_dict('records')
#                 else:
#                     temp_list = []
#                     for year, count in counts_per_year.items():
#                         if count > 0 and not df.empty:
#                             year_sample = df[df['year'] == year].sample(n=count).to_dict('records')
#                             temp_list.extend(year_sample)
#                     final_selection_data = temp_list
#                 random.shuffle(final_selection_data)
#                 pool_lookup = {p['cid']: p for p in pool} # Use CID for lookup
#                 final_ordered_selection = [pool_lookup[item['cid']] for item in final_selection_data if item['cid'] in pool_lookup]
#                 st.session_state.final_selection = final_ordered_selection
#                 st.session_state.final_citations = []; st.session_state.citation_errors = []
#                 st.rerun()
#     else:
#         st.warning("Scraping finished, but no papers were collected.")
    
#     if st.session_state.app_state == 'done':
#         if st.button("Start New Scrape"):
#             st.session_state.app_state = 'initial'; st.session_state.reference_pool = []; st.session_state.final_selection = []; st.session_state.final_citations = []; st.session_state.citation_errors = []
#             st.rerun()



# -----------------------------------------------------------------------

import streamlit as st
import time
import datetime
import pandas as pd
import re
import random
from docx import Document
from io import BytesIO

from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException

# --- Page Configuration and CSS ---
st.set_page_config(page_title="Advanced Scholar Scraper", page_icon="🔬", layout="wide")

def load_css(file_name):
    try:
        with open(file_name) as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    except FileNotFoundError:
        st.warning(f"'{file_name}' not found. UI will be unstyled.")
load_css("style.css")

# --- Helper Functions ---
def create_word_document(citations_list):
    document = Document()
    document.add_heading('References', level=1)
    for citation in citations_list:
        document.add_paragraph(citation, style='List Number')
    bio = BytesIO()
    document.save(bio)
    return bio.getvalue()

def create_csv_file(citations_list):
    df = pd.DataFrame(citations_list, columns=["Reference"])
    return df.to_csv(index=False).encode('utf-8')

def parse_citation_data(citations_dict):
    """Parses title and year from a dictionary of citation strings using your rules."""
    title, year = "Title not found", 0
    
    # Rule for MLA/Chicago (quotes)
    if "Chicago" in citations_dict:
        match = re.search(r'"(.*?)"', citations_dict["Chicago"])
        if match: title = match.group(1)
    elif "MLA" in citations_dict:
        match = re.search(r'“(.*?)”', citations_dict["MLA"])
        if match: title = match.group(1)
    
    # Rule for APA (text between year parenthesis and next period)
    elif "APA" in citations_dict:
        match = re.search(r'\(\d{4}\)\.\s(.*?)\.', citations_dict["APA"])
        if match: title = match.group(1)

    # Rule for Harvard (text between year and next period)
    elif "Harvard" in citations_dict:
        match = re.search(r'\d{4}\.\s(.*?)\.', citations_dict["Harvard"])
        if match: title = match.group(1)
    
    # Find year from any format
    for fmt_text in citations_dict.values():
        year_match = re.search(r'\b(20\d{2})\b', fmt_text)
        if year_match:
            year = int(year_match.group(0))
            break # Stop once a year is found
            
    return title, year

# --- NEW "PARSE-FIRST" SCRAPING ENGINE ---
def resume_scraping(driver, years_to_scrape, pages_per_year, topic):
    reference_pool = []
    wait = WebDriverWait(driver, 10)
    
    for i, year_to_search in enumerate(years_to_scrape):
        # Navigate to the correct year's page if it's not the first one
        if i > 0:
            st.toast(f"Navigating to year: {year_to_search}...")
            url = f"https://scholar.google.com/scholar?q={topic.replace(' ', '+')}&as_ylo={year_to_search}&as_yhi={year_to_search}"
            driver.get(url)
        else:
             st.toast(f"Starting with year: {year_to_search}...")

        for page_num in range(pages_per_year):
            st.toast(f"Processing page {page_num + 1} for year {year_to_search}...")
            try:
                wait.until(EC.presence_of_element_located((By.ID, "gs_res_ccl_mid")))
                papers_on_page = driver.find_elements(By.CSS_SELECTOR, "div.gs_r.gs_or.gs_scl")
                
                if not papers_on_page: break

                # Get unique IDs for all papers on the page first
                cids = [paper.get_attribute('data-cid') for paper in papers_on_page if paper.get_attribute('data-cid')]
                
                for cid in cids:
                    try:
                        # Re-find the container by its stable CID to avoid stale elements
                        paper_container = wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, f"div[data-cid='{cid}']")))
                        cite_button = paper_container.find_element(By.CSS_SELECTOR, "a.gs_or_cit.gs_or_btn")
                        driver.execute_script("arguments[0].click();", cite_button)
                        
                        pop_up = wait.until(EC.visibility_of_element_located((By.ID, "gs_cit")))
                        rows = pop_up.find_elements(By.TAG_NAME, "tr")
                        
                        # Scrape all formats into a dictionary
                        citations_dict = {row.find_element(By.TAG_NAME, "th").text: row.find_element(By.TAG_NAME, "td").text for row in rows}
                        
                        title, parsed_year = parse_citation_data(citations_dict)

                        if title != "Title not found":
                            reference_pool.append({
                                "title": title, 
                                "year": parsed_year, 
                                "citations": citations_dict # Store all formats
                            })
                        
                        close_button = pop_up.find_element(By.ID, "gs_cit-x")
                        driver.execute_script("arguments[0].click();", close_button)
                        wait.until(EC.invisibility_of_element_located((By.ID, "gs_cit")))
                    except Exception:
                        continue # Skip this paper if any error occurs
            except TimeoutException:
                break # No results on this page
            
            try: # Pagination
                next_button = driver.find_element(By.LINK_TEXT, "Next")
                driver.execute_script("arguments[0].scrollIntoView(true);", next_button)
                time.sleep(0.5)
                next_button.click()
            except NoSuchElementException:
                break # No more pages for this year
    
    st.toast("Scraping complete!")
    return reference_pool

# --- Initialize Session State ---
if 'app_state' not in st.session_state: st.session_state.app_state = 'initial'
if 'driver' not in st.session_state: st.session_state.driver = None
if 'reference_pool' not in st.session_state: st.session_state.reference_pool = []
if 'final_citations' not in st.session_state: st.session_state.final_citations = []

# --- UI Sidebar ---
with st.sidebar:
    st.header("Scraping Strategy")
    search_topic = st.text_input("Enter Research Topic", placeholder="e.g., Quantum computing")
    current_year = datetime.date.today().year
    year_options = list(range(2020, current_year + 1)); year_options.sort(reverse=True)
    selected_years = st.multiselect("Select Years to Scrape (2020+)", options=year_options, default=year_options[0:1])
    pages_to_scrape = st.number_input("Pages to Scrape per Year", min_value=1, max_value=10, value=1, step=1)
    st.session_state.citation_format = st.selectbox("Choose Final Citation Format", ["Chicago", "MLA", "APA", "Harvard"])

    if st.button("1. Launch Browser & Prepare", use_container_width=True, type="primary"):
        if search_topic and selected_years:
            st.session_state.scrape_settings = {"topic": search_topic, "years": selected_years, "pages": pages_to_scrape}
            # Reset all states for a new search
            st.session_state.app_state = 'initial'; st.session_state.reference_pool = []; st.session_state.final_citations = []
            try:
                if 'driver' in st.session_state and st.session_state.driver: st.session_state.driver.quit()
                options = webdriver.ChromeOptions()
                st.session_state.driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=options)
                first_year = selected_years[0]
                url = f"https://scholar.google.com/scholar?q={search_topic.replace(' ', '+')}&as_ylo={first_year}&as_yhi={first_year}"
                st.session_state.driver.get(url)
                st.session_state.app_state = 'browser_open'; st.rerun()
            except Exception as e:
                st.error(f"Failed to launch browser: {e}")
        else:
            st.warning("Please enter a topic and select at least one year.")
    
    st.markdown("---")
    if st.button("Quit Browser Session", use_container_width=True, type="secondary"):
        if 'driver' in st.session_state and st.session_state.driver:
            st.session_state.driver.quit()
            st.session_state.driver = None
            st.session_state.app_state = 'initial'; st.session_state.reference_pool = []; st.session_state.final_citations = []
            st.success("Browser session closed."); time.sleep(1); st.rerun()

# --- Main Page Area ---
st.title("🔬 Advanced Research Assistant")

if st.session_state.app_state in ['initial', 'browser_open', 'scraping']:
    if st.session_state.app_state == 'initial':
        st.info("⬅️ Set your scraping strategy and click 'Launch & Prepare' to begin.")
    elif st.session_state.app_state == 'browser_open':
        st.subheader("Action Required")
        st.success("Browser is open. Please solve any CAPTCHA if it appears.")
        st.info("Once you see the normal search results list, click the button below to begin scraping.")
        if st.button("2. Scrape All Pages", use_container_width=True):
            st.session_state.app_state = 'scraping'; st.rerun()
    elif st.session_state.app_state == 'scraping':
        with st.spinner("Scraping all specified pages... This may take several minutes."):
            settings = st.session_state.scrape_settings
            results = resume_scraping(st.session_state.driver, settings['years'], settings['pages'], settings['topic'])
            st.session_state.reference_pool = results
            st.session_state.app_state = 'done'
            if 'driver' in st.session_state and st.session_state.driver:
                st.session_state.driver.quit()
                st.session_state.driver = None
            st.rerun()

elif st.session_state.app_state == 'done':
    st.subheader("Reference Pool Created")
    pool = st.session_state.reference_pool
    if pool:
        df = pd.DataFrame([p for p in pool if isinstance(p.get('year'), int) and p.get('year') > 0])
        st.success(f"Created a pool with **{len(df)}** valid papers.")
        if not df.empty:
            st.write("#### Pool Summary (Papers per Year)")
            st.table(df['year'].value_counts().sort_index(ascending=False))
        
        st.markdown("---")
        st.subheader("Build Your Reference List")
        mixing_strategy = st.radio("How do you want to select references?", ["Randomly from entire pool (Any)", "Specify count per year (Choose)"])
        
        with st.form("mixer_form"):
            total_random_count, counts_per_year = 0, {}
            if mixing_strategy == "Randomly from entire pool (Any)":
                if not df.empty: total_random_count = st.number_input("Total references to generate:", min_value=1, max_value=len(df), value=min(10, len(df)), step=1)
            else:
                if not df.empty:
                    st.write("**Enter the number of references to select from each year:**")
                    for year in sorted(df['year'].unique(), reverse=True):
                        max_for_year = len(df[df['year'] == year])
                        counts_per_year[year] = st.number_input(f"Count for {year} (max: {max_for_year})", min_value=0, max_value=max_for_year, value=0, key=f"year_{year}")
            
            submitted = st.form_submit_button("Generate & Shuffle List")
            if submitted:
                final_selection_data = []
                if mixing_strategy == "Randomly from entire pool (Any)":
                    if total_random_count > 0 and not df.empty:
                        final_selection_data = df.sample(n=total_random_count).to_dict('records')
                else:
                    temp_list = []
                    for year, count in counts_per_year.items():
                        if count > 0 and not df.empty:
                            year_sample = df[df['year'] == year].sample(n=count).to_dict('records')
                            temp_list.extend(year_sample)
                    final_selection_data = temp_list
                
                random.shuffle(final_selection_data)
                
                # Instantly get the pre-scraped citations in the correct format
                citation_format = st.session_state.citation_format
                st.session_state.final_citations = [p['citations'].get(citation_format, f"Format '{citation_format}' not found for this paper.") for p in final_selection_data]

    if st.session_state.final_citations:
        st.markdown("---")
        st.subheader("✅ Your Generated References")
        st.text_area("Formatted and shuffled citations:", "\n\n".join(st.session_state.final_citations), height=300)
        
        col1, col2 = st.columns(2)
        with col1:
            st.download_button(label="Download as Word (.docx)", data=create_word_document(st.session_state.final_citations), file_name="references.docx", mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document", use_container_width=True)
        with col2:
            st.download_button(label="Download as CSV", data=create_csv_file(st.session_state.final_citations), file_name="references.csv", mime="text/csv", use_container_width=True)

    if st.button("Start New Scrape"):
        st.session_state.app_state = 'initial'
        st.session_state.reference_pool = []
        st.session_state.final_citations = []
        st.rerun()
